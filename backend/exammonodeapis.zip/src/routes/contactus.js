var express = require('express');
var router = express.Router();
var ContactusModel = require('../models/contactus');
const authUtil = require('./authUtil.js');
var timestamp = new Date();
var CommonModel = require('../models/common');
const config = require('./../config');


timestamp = timestamp.getTime() + timestamp.getTimezoneOffset() * 60000; //to UTC timestamp


router.post('/send-email', async(req, res, next) => {
    var rewParams = req.body
    if(rewParams.email != undefined){
        //send OTP in email
        var mailOptions = {
            from: 'Sansar Vivah Kendra<info@sansarvivah.com>',
            to: config.adminEmail,
            subject: "New Inquiry from " + rewParams.your_name,
            html: "Hi,<br /><br />New inquiry received from contact us page, details mentioned below<br /><br /><b>Name: </b>"+ rewParams.your_name +"</b><br /><br /><b>Email: </b>"+ rewParams.email +"</b><br /><br /><b>Subject: </b>"+ rewParams.subject +"</b><br /><br /><b>Message: </b>"+ rewParams.message +"</b><br /><br /><br /><br />Warm Regards,<br />Sansar Vivah Team"
        };
        CommonModel.sendVivahEmail(mailOptions, function(err, result){
            if(err){
                res.status(200).json({status: "error", message: err});
            } else {
                res.status(200).json({
                    "status": "success",
                    "message": "Email sent successfully, we will contact you soon"
                });
            }
        })
    }else{
        res.status(200).json({
            "status": "error",
            "message": "Missing email details"
        });
    }
});

router.get('/get-contact-details', async (req, res, next) => {
    var params = req.query
    ContactusModel.getRecordById(params,function(err, result){
        if(err){
            console.log(err)
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.post('/getRecordById', authUtil.ensureAuthenticated, async (req, res, next) => {
    var params = req.body
    ContactusModel.getRecordById(params,function(err, result){
        if(err){
            console.log(err)
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.put('/updaterecord', authUtil.ensureAuthenticated, async (req, res, next) => {
    const postData = req.body;
    if(postData.address == undefined || postData.address == ""){
        res.status(200).json({
            "status": "error",
            "message": "Address is required."
        });
    }
    
    if(postData.contact_numbers == undefined || postData.contact_numbers == ""){
        res.status(200).json({
            "status": "error",
            "message": "Contact number(s) is required."
        });
    }

    if(postData.timings == undefined || postData.timings == ""){
        res.status(200).json({
            "status": "error",
            "message": "Timing is required."
        });
    }

    /* if(postData.email == undefined || postData.email == ""){
        res.status(200).json({
            "status": "error",
            "message": "Email is required."
        });
    }

    if(postData.longitude == undefined || postData.longitude == ""){
        res.status(200).json({
            "status": "error",
            "message": "Longitude is required."
        });
    }

    if(postData.latitude == undefined || postData.latitude == ""){
        res.status(200).json({
            "status": "error",
            "message": "Latitude is required."
        });
    } */

    if(postData.additional_details == undefined || postData.additional_details == ""){
        res.status(200).json({
            "status": "error",
            "message": "Additional Details is required."
        });
    }
    const welcomeNote = postData.welcome_note || "";
    
    delete postData.welcome_note 

    ContactusModel.updateRecords(postData, function(err, result){
        if(err){
            res.status(200).json({status: "error", message: "There is some problem, please try again later."});
        } else {
            ContactusModel.updateSettingRecords({welcome_note: welcomeNote}, function(err, result1){
                if(err){
                    res.status(200).json({status: "error", message: "There is some problem, please try again later."});
                } else {
                    var response = {
                        "status": "success",
                        "message": "Contact updated successfully",
                    }
                    res.status(200).json(response);
                }
            })
        }
    })
    
});

module.exports = router;