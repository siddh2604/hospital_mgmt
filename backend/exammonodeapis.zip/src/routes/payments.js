const config = require('../config');
var express = require('express');
var router = express.Router();
var Payment = require('../models/payment');
var Plans = require('../models/plan');
var CommonModel = require('../models/common');
const authUtil = require('./authUtil.js');
var randomstring = require("randomstring");
var timestamp = new Date();
timestamp = timestamp.getTime() + timestamp.getTimezoneOffset() * 60000; //to UTC timestamp
var Razorpay = require('razorpay');
var instance = new Razorpay({
  key_id: config.razorpayKeyId,
  key_secret: config.razorpayKeySecret
});
var crypto = require('crypto');

router.post('/order', authUtil.ensureAuthenticated, function(req, res, next){
	var postData = req.body;
	if(typeof(postData.planId) === "undefined"){
		res.status(200).json({status: "error", message: "Plan ID is required."});
		return;
	}
	
	Plans.getRecordById({id: postData.planId}, function(err, response){
		if (err) {
			console.log(err);
			res.status(200).json({status: "error", message: "Getting error in payment, please try again"});
		} else {
			if(response == null){
				res.status(200).json({status: "error", message: "Invalid plan, please try with valid plan"});
			}else{
				var orderPromise = instance.orders.create({amount: ((response.plan_price) * 100), currency: "INR", receipt: "Plan_"+randomstring.generate(3)+timestamp, payment_capture: true, notes:{"userId": req.user.id}});
				var date = new Date(); 
				orderPromise.then(function(orderResult){
					var paymentData = {
						plan_name: response.plan_name,
						validity: parseInt(response.plan_validity),
						amount: response.plan_price,
						contact_view_limit: response.contact_limit,
						remaining_contact_view_limit: response.contact_limit,
						expired_at: (new Date(date.setMonth(date.getMonth() + response.plan_validity))).toISOString(),
						user_id: req.user.id,
						orderId: orderResult.id,
						razorpayOrderId: orderResult.id,
						razorpayOrderData: JSON.stringify(orderResult),
						plan_id: response.id
					}
					Payment.insertRecord(paymentData, function (err, newUser) {
						if (err) {
							res.status(200).json({status: "error", message: err});
						} else {
							//req.user.mobile_number
							const fullName = req.user.first_name + " " + req.user.middle_name + " " + req.user.last_name;
							res.status(200).json({status: "success", message: "Order created successfully.", orderid: orderResult.id, emailAddress: req.user.email, mobileNumber: "8690415675", fullName: fullName, amount: paymentData.amount, currency: "INR"});
						}
					});
				}).catch(function(err){
					res.status(200).json({status: "error", message: err.error.description});
				});
			}
		}
	})
});

router.post('/verify-signature', authUtil.ensureAuthenticated, function(req, res, next){
	var postData = req.body;
	var timestamp = new Date();
	
	if(typeof(postData.orderId) === "undefined"){
		res.status(200).json({status: "error", message: "orderId required."});
	}
	if(typeof(postData.paymentId) === "undefined"){
		res.status(200).json({status: "error", message: "paymentId required."});
	}

	const hmac = crypto.createHmac('sha256', config.razorpayKeySecret);
	hmac.update(postData.orderId + "|" + postData.paymentId);
	var signature = hmac.digest('hex');
	var paymentParams = {};
	if(signature == postData.signature){
		paymentParams = {
			razorpayPaymentId: postData.paymentId,
			status: "success"
		}
	} else {
		paymentParams = {
			status: "failed"
		}
	}
	//console.log(paymentParams);return;
	const condition = {whereCon: [{field: "orderId", value: postData.orderId}]};
	Payment.getRecords(condition, function(err, payment){
		if(err){
			res.status(200).json({status: "error", message: "There is some problem updating payment status"});
		} else {
			if(payment.length == 0){
				res.status(200).json({status: "error", message: "Payment details not found."});
				return;
			}
			paymentParams.id = payment[0].id;

			Payment.updateRecord(paymentParams, function(err, response){
				if(err){
					res.status(200).json({status: "error", message: "There is some problem updating payment status"});
				}else{
					console.log('Payment 1')
					if(paymentParams.status == "success"){						
						console.log('Payment 2')

						CommonModel.customUpdate({table: 'users', whereCon: [{field: "id", value: req.user.id}]}, { isPaidUser: 1}, function(err, responseCount){
							if(err){
								res.status(200).json({status: "error", message: "There is some error, please try again later."});
							} else {
								//Send Email to admin regarding payment success
								var mailOptions = {
									from: 'Sansar Vivah Kendra<info@sansarvivah.com>',
									to: config.adminEmail,
									subject: "Payment successful",
									html: "Hello Admin," + "<br /><br />Payment of Rs. "+ payment[0].amount +" is successfully done by "+ req.user.first_name + ' ' + req.user.middle_name + ' ' + req.user.last_name + " for the " + payment[0].plan_name + " plan.<br /><br />Warm Regards,<br />Sansar Vivah Team"
								};
								CommonModel.sendVivahEmail(mailOptions, function(err, result){
									if(err){
										res.status(200).json({status: "error", message: err});
									} else {
										CommonModel.removeViewedContacts({user_id: req.user.id}, function(err, resultContacts){
											if(err){
												res.status(200).json({status: "error", message: err});
											} else {
												res.status(200).json({status: "success", message: "Payment is successful."});								
											}
										});
									}
								})	
							}
						})
					} else {
						console.log('Payment 3')
						res.status(200).json({status: "error", message: "Payment failed."});
					}
				}
			});
		}
	});
});

router.post('/offlinePayment', authUtil.ensureAuthenticated, function(req, res, next){
	var postData = req.body;
	var timestamp = new Date();
	
	if(typeof(postData.user_id) === "undefined"){
		res.status(200).json({status: "error", message: "User ID is required."});
	}

	if(typeof(postData.plan_id) === "undefined"){
		res.status(200).json({status: "error", message: "Plan is required."});
	}

	const condition = {whereCon: [{field: "user_id", value: postData.user_id}, {field: "status", value: 'Success'}], expireAt: true};
	Payment.getRecords(condition, function(err, payment){
		if (err) {
			console.log(err);
			res.status(200).json({status: "error", message: "Getting error in payment, please try again"});
		} else {
			const remainingViews = (payment.length > 0)? payment[0].remaining_contact_view_limit : 0;
			Plans.getRecordById({id: postData.plan_id}, function(err, response){
				if (err) {
					console.log(err);
					res.status(200).json({status: "error", message: "Getting error in payment, please try again"});
				} else {
					if(response == null){
						res.status(200).json({status: "error", message: "Invalid plan, please try with valid plan"});
					}else{
						var date = new Date(); 
						var paymentData = {
							plan_name: response.plan_name,
							validity: parseInt(response.plan_validity),
							amount: response.plan_price,
							contact_view_limit: (response.contact_limit + remainingViews),
							previous_balance: remainingViews,
							payment_method: "Offline",
							remaining_contact_view_limit: (parseInt(response.contact_limit) + remainingViews),
							expired_at: (new Date(date.setMonth(date.getMonth() + response.plan_validity))).toISOString(),
							user_id: postData.user_id,
							plan_id: response.id,
							status: "Success"
						}
						Payment.insertRecord(paymentData, function (err, newUser) {
							if (err) {
								res.status(200).json({status: "error", message: err});
							} else {
								CommonModel.removeViewedContacts({user_id: postData.user_id}, function(err, resultContacts){
									if(err){
										res.status(200).json({status: "error", message: err});
									} else {
										res.status(200).json({status: "success", message: "Plan added successfully."});		
									}
								});
							}
						});
					}
				}
			})
		}
	})
});

router.post("/*", authUtil.ensureAuthenticated, function (req, res, next) {
	RequestLog.add({req: req, error: {message: "forbidden"}, response: {message: "forbidden"} });
	res.status(403).json({message: "forbidden"});
});

module.exports = router;