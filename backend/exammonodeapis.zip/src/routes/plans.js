var express = require('express');
var router = express.Router();
var PlanModel = require('../models/plan');
const authUtil = require('./authUtil.js');
var timestamp = new Date();
var multer  =   require('multer');
var path = require('path');
const { stringify } = require('querystring');
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'public/images/plans/')
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
})
   
var upload = multer({ storage: storage })

timestamp = timestamp.getTime() + timestamp.getTimezoneOffset() * 60000; //to UTC timestamp

router.get('/get-plans', async (req, res, next) => {
    const condition = {whereCon: [{field: "status", value: "Active"}]};
    PlanModel.getRecords(condition, function(err, result){
        if(err){
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            //var result = [{id: 1,plan_name: "SILVER", showSpecialPrice: 0, specialPrice: "", plan_validity: 3, plan_price: 700, contact_limit: 30, websiteAccess: 1,unlimitedProfiles: 1, expressInterest: 1, shortlistProfiles: 1, sendMessages: 1, advisor: 0, introductionMettings: 0, handpickedMatches: 0, premiumBenefits: 0},{id: 2,plan_name: "GOLD", showSpecialPrice: 0, specialPrice: "", plan_validity: 6, plan_price: 1200, contact_limit: 60, websiteAccess: 1,unlimitedProfiles: 1, expressInterest: 1, shortlistProfiles: 1, sendMessages: 1, advisor: 0, introductionMettings: 0, handpickedMatches: 0, premiumBenefits: 0},{id: 3,plan_name: "PLATINUM", showSpecialPrice: 0, specialPrice: "", plan_validity: 12, plan_price: 1800, contact_limit: 110, websiteAccess: 1,unlimitedProfiles: 1, expressInterest: 1, shortlistProfiles: 1, sendMessages: 1, advisor: 0, introductionMettings: 0, handpickedMatches: 0, premiumBenefits: 0},{id: 4,plan_name: "PLATINUM SPECIAL", showSpecialPrice: 1, specialPrice: "11000/- (1000 + 10000) <br /> Membership Only Rs.1000/- <br /> Rs.10000/- After You will Get Your Perfect Match ", plan_validity: 12, plan_price: 11000, contact_limit: 100, websiteAccess: 1,unlimitedProfiles: 1, expressInterest: 1, shortlistProfiles: 1, sendMessages: 1, advisor: 1, introductionMettings: 1, handpickedMatches: 1, premiumBenefits: 1}];
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.post('/getrecords', async (req, res, next) => {
    PlanModel.getRecords({},function(err, result){
        if(err){
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.post('/getRecordById', authUtil.ensureAuthenticated, async (req, res, next) => {
    var params = req.body
    PlanModel.getRecordById(params,function(err, result){
        if(err){
            console.log(err)
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.post('/addrecord', authUtil.ensureAuthenticated, async (req, res, next) => {
    const postData = req.body;
    if(postData.plan_name == undefined || postData.plan_name == ""){
        res.status(200).json({
            "status": "error",
            "message": "Plan name is required."
        });
    }
    
    if(postData.plan_validity == undefined || postData.plan_validity == ""){
        res.status(200).json({
            "status": "error",
            "message": "Validity is required."
        });
    }

    if(postData.plan_price == undefined || postData.plan_price == ""){
        res.status(200).json({
            "status": "error",
            "message": "Plan amount is required."
        });
    }

    if(postData.contact_limit == undefined || postData.contact_limit == ""){
        res.status(200).json({
            "status": "error",
            "message": "Contact limit is required."
        });
    }
    
    PlanModel.insertRecord(postData, function(err, result){
        if(err){
            res.status(200).json({status: "error", message: "There is some problem, please try again later."});
        } else {
            var response = {
                "status": "success",
                "message": "Plan added successfully",
            }
            res.status(200).json(response);
        }
    })
    
});

router.put('/updaterecord', authUtil.ensureAuthenticated, async (req, res, next) => {
    const postData = req.body;
    if(postData.plan_name == undefined || postData.plan_name == ""){
        res.status(200).json({
            "status": "error",
            "message": "Plan name is required."
        });
    }
    
    if(postData.plan_validity == undefined || postData.plan_validity == ""){
        res.status(200).json({
            "status": "error",
            "message": "Validity is required."
        });
    }

    if(postData.plan_price == undefined || postData.plan_price == ""){
        res.status(200).json({
            "status": "error",
            "message": "Plan amount is required."
        });
    }

    if(postData.contact_limit == undefined || postData.contact_limit == ""){
        res.status(200).json({
            "status": "error",
            "message": "contact limit is required."
        });
    }
    
    PlanModel.updatePlan(postData, function(err, result){
        if(err){
            res.status(200).json({status: "error", message: "There is some problem, please try again later."});
        } else {
            var response = {
                "status": "success",
                "message": "Plan updated successfully",
            }
            res.status(200).json(response);
        }
    })
    
});

router.delete('/deleterecords', authUtil.ensureAuthenticated, async (req, res, next) => {
    const postData = req.body;
    if(postData.length < 1){
        res.status(200).json({
            "status": "error",
            "message": "Records not found to delete."
        });
    }

    PlanModel.deletePlan(postData, function(err, result){
        if(err){
            res.status(200).json({status: "error", message: "There is some problem, please try again later."});
        } else {
            var response = {
                "status": "success",
                "message": "Plan deleted successfully",
            }
            res.status(200).json(response);
        }
    })
    
});

/* router.post('/uploadgallery', async (req, res, next) => { */
router.post('/uploadgallery', upload.single('planimages'), function (req, res) {
    if (req.fileValidationError) {
        res.status(200).json({
            "status": "error",
            "message": req.fileValidationError
        });
    }else if (!req.file) {
        res.status(200).json({
            "status": "error",
            "message": "Please select an image to upload."
        });
    }else{
        res.status(200).json({
            "status": "success",
            "file_name": req.file.filename,
            "message": "Image uploaded successfully"
        });
    }
    
})

module.exports = router;