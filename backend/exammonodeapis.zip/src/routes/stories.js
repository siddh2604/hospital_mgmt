var express = require('express');
var router = express.Router();
var StoryModel = require('../models/story');
const authUtil = require('./authUtil.js');
var timestamp = new Date();
var multer  =   require('multer');
var path = require('path');
const { stringify } = require('querystring');
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'public/images/users/story/')
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
  })
   
var upload = multer({ storage: storage })
  

timestamp = timestamp.getTime() + timestamp.getTimezoneOffset() * 60000; //to UTC timestamp

router.get('/get-top10-story', async (req, res, next) => {
    const condition = {whereCon: [{field: "status", value: "Published"}, {field: "published", value: 1}]};
    StoryModel.getTop10story(condition, function(err, result){
        if(err){
            console.log(err);
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.get('/get-mystory', authUtil.ensureAuthenticated, async (req, res, next) => {
    const condition = {whereCon: [{field: "user_id", value: req.user.id}]};
    StoryModel.getTop10story(condition, function(err, result){
        if(err){
            console.log(err);
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.post('/getstories', authUtil.ensureAuthenticated, async (req, res, next) => {
    StoryModel.getStories({},function(err, result){
        if(err){
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.post('/getStoryById', authUtil.ensureAuthenticated, async (req, res, next) => {
    var params = req.body
    StoryModel.getStoriesById(params,function(err, result){
        if(err){
            console.log(err)
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.post('/addstory', authUtil.ensureAuthenticated, async (req, res, next) => {
    const postData = req.body;
    
    if(postData.member_name == undefined || postData.member_name == ""){
        res.status(200).json({
            "status": "error",
            "message": "Member Name is required."
        });
    }

    if(postData.member_email == undefined || postData.member_email == ""){
        res.status(200).json({
            "status": "error",
            "message": "Member Email is required."
        });
    }

    if(postData.partner_name == undefined || postData.partner_name == ""){
        res.status(200).json({
            "status": "error",
            "message": "Partner Name is required."
        });
    }

    if(postData.partner_email == undefined || postData.partner_email == ""){
        res.status(200).json({
            "status": "error",
            "message": "Partner Name is required."
        });
    }

    if(postData.title == undefined || postData.title == ""){
        postData.title = postData.member_name + " and " + postData.partner_name;
    }

    if(postData.first_meet_date == undefined || postData.first_meet_date == ""){
        res.status(200).json({
            "status": "error",
            "message": "First Meet date is required."
        });
    }

    if(postData.wedding_date == undefined || postData.wedding_date == ""){
        res.status(200).json({
            "status": "error",
            "message": "Wedding date is required."
        });
    }
    
    if(postData.story_description == undefined || postData.story_description == ""){
        res.status(200).json({
            "status": "error",
            "message": "Story description is required."
        });
    }

    if(!postData.user_id){
        postData.user_id = req.user.id;
    }
    const condition = {whereCon: [{field: "user_id", value: postData.user_id}]};
    StoryModel.getTop10story(condition, function(err, result){
        if(err){
            console.log(err);
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            if(result.length > 0){
                res.status(200).json({
                    "status": "error",
                    "message": "Story already added for this user"
                });
            }else{
                StoryModel.insertStory(postData, function(err, result){
                    if(err){
                        res.status(200).json({status: "error", message: "There is some problem, please try again later."});
                    } else {
                        const condition = {whereCon: [{field: "user_id", value: postData.user_id}]};
                        StoryModel.getTop10story(condition, function(err, result){
                            if(err){
                                console.log(err);
                                res.status(200).json({
                                    "status": "error",
                                    "message": "There is some problem, please try again later"
                                });
                                return
                            }else{
                                var response = {
                                    "status": "success",
                                    "message": "Story added successfully",
                                    "items": result
                                }
                                res.status(200).json(response);    
                            }
                        })
                    }
                })
            }  
        }
    })
});

router.put('/updatestory', authUtil.ensureAuthenticated, async (req, res, next) => {
    const postData = req.body;
    if(postData.title == undefined || postData.title == ""){
        res.status(200).json({
            "status": "error",
            "message": "Title is required."
        });
    }
    
    if(postData.member_name == undefined || postData.member_name == ""){
        res.status(200).json({
            "status": "error",
            "message": "Member Name is required."
        });
    }

    if(postData.partner_name == undefined || postData.partner_name == ""){
        res.status(200).json({
            "status": "error",
            "message": "Partner Name is required."
        });
    }

    if(postData.story_description == undefined || postData.story_description == ""){
        res.status(200).json({
            "status": "error",
            "message": "Story description is required."
        });
    }
    
    StoryModel.updateStory(postData, function(err, result){
        if(err){
            res.status(200).json({status: "error", message: "There is some problem, please try again later."});
        } else {
            var response = {
                "status": "success",
                "message": "Story updated successfully",
            }
            res.status(200).json(response);
        }
    })
    
});

router.delete('/deletestory', authUtil.ensureAuthenticated, async (req, res, next) => {
    const postData = req.body;
    if(postData.length < 1){
        res.status(200).json({
            "status": "error",
            "message": "Records not found to delete."
        });
    }

    StoryModel.deleteStory(postData, function(err, result){
        if(err){
            res.status(200).json({status: "error", message: "There is some problem, please try again later."});
        } else {
            var response = {
                "status": "success",
                "message": "Story deleted successfully",
            }
            res.status(200).json(response);
        }
    })
    
});

/* router.post('/uploadgallery', async (req, res, next) => { */
router.post('/uploadgallery', upload.single('storyimages'), function (req, res) {
    if (req.fileValidationError) {
        res.status(200).json({
            "status": "error",
            "message": req.fileValidationError
        });
    }else if (!req.file) {
        res.status(200).json({
            "status": "error",
            "message": "Please select an image to upload."
        });
    }else{
        res.status(200).json({
            "status": "success",
            "file_name": req.file.filename,
            "message": "Image uploaded successfully"
        });
    }
    
})

module.exports = router;