var express = require('express');
var router = express.Router();
var BranchModel = require('../models/branch');
const authUtil = require('./authUtil.js');
var timestamp = new Date();

timestamp = timestamp.getTime() + timestamp.getTimezoneOffset() * 60000; //to UTC timestamp

router.get('/get-branches', async (req, res, next) => {
    const condition = {whereCon: [{field: "status", value: "Active"}]};
    BranchModel.getRecords(condition,function(err, result){
        if(err){
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.post('/getrecords', authUtil.ensureAuthenticated, async (req, res, next) => {
    BranchModel.getRecords({},function(err, result){
        if(err){
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.post('/getRecordById', authUtil.ensureAuthenticated, async (req, res, next) => {
    var params = req.body
    BranchModel.getRecordById(params,function(err, result){
        if(err){
            console.log(err)
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var response = {
                "status": "success",
                "items": result
            }
            res.status(200).json(response);    
        }
    })
});

router.post('/addrecord', authUtil.ensureAuthenticated, async (req, res, next) => {
    const postData = req.body;
    if(postData.branch_name == undefined || postData.branch_name == ""){
        res.status(200).json({
            "status": "error",
            "message": "Branch name is required."
        });
    }
    
    if(postData.address == undefined || postData.address == ""){
        res.status(200).json({
            "status": "error",
            "message": "Address is required."
        });
    }

    if(postData.contact_numbers == undefined || postData.contact_numbers == ""){
        res.status(200).json({
            "status": "error",
            "message": "Contact numbers is required."
        });
    }

    if(postData.email == undefined || postData.email == ""){
        res.status(200).json({
            "status": "error",
            "message": "Email is required."
        });
    }

    if(postData.status == undefined || postData.status == ""){
        res.status(200).json({
            "status": "error",
            "message": "Status is required."
        });
    }
    
    BranchModel.insertRecord(postData, function(err, result){
        if(err){
            res.status(200).json({status: "error", message: "There is some problem, please try again later."});
        } else {
            var response = {
                "status": "success",
                "message": "Branch added successfully",
            }
            res.status(200).json(response);
        }
    })
    
});

router.put('/updaterecord', authUtil.ensureAuthenticated, async (req, res, next) => {
    const postData = req.body;
    if(postData.branch_name == undefined || postData.branch_name == ""){
        res.status(200).json({
            "status": "error",
            "message": "Branch name is required."
        });
    }
    
    if(postData.address == undefined || postData.address == ""){
        res.status(200).json({
            "status": "error",
            "message": "Address is required."
        });
    }

    if(postData.contact_numbers == undefined || postData.contact_numbers == ""){
        res.status(200).json({
            "status": "error",
            "message": "Contact numbers is required."
        });
    }

    if(postData.email == undefined || postData.email == ""){
        res.status(200).json({
            "status": "error",
            "message": "Email is required."
        });
    }

    if(postData.status == undefined || postData.status == ""){
        res.status(200).json({
            "status": "error",
            "message": "Status is required."
        });
    }
    
    BranchModel.updateBranch(postData, function(err, result){
        if(err){
            res.status(200).json({status: "error", message: "There is some problem, please try again later."});
        } else {
            var response = {
                "status": "success",
                "message": "Branch updated successfully",
            }
            res.status(200).json(response);
        }
    })
    
});

router.delete('/deleterecords', authUtil.ensureAuthenticated, async (req, res, next) => {
    const postData = req.body;
    if(postData.length < 1){
        res.status(200).json({
            "status": "error",
            "message": "Records not found to delete."
        });
    }

    BranchModel.deleteBranch(postData, function(err, result){
        if(err){
            res.status(200).json({status: "error", message: "There is some problem, please try again later."});
        } else {
            var response = {
                "status": "success",
                "message": "Branch deleted successfully",
            }
            res.status(200).json(response);
        }
    })
    
});

module.exports = router;