var express = require('express');
var router = express.Router();
var bcrypt = require('bcryptjs');
var CommonModel = require('../models/common');
const jwt = require('jsonwebtoken');
const config = require('./../config');
const authUtil = require('./authUtil.js');
var timestamp = new Date();
timestamp = timestamp.getTime() + timestamp.getTimezoneOffset() * 60000; //to UTC timestamp
var moment = require('moment');

/**Exammo APIs start */

/**
 * Login api
 */
router.post('/login', async (req, res, next) => {
    try {
        const postData = req.body;
        if(!postData.username){ res.status(201).json({ "status": "error", "message": "Username is required." }); return }
        if(!postData.password){ res.status(201).json({ "status": "error", "message": "Password is required." }); return }
    
        let getUser = await CommonModel.getRecords({whereCon: [{field: "username", value: postData.username}], table: 'users', select: 'id, mobile_number, is_verified, password, approved_status, email, username'});

        if(getUser.length){
            let isMatchedPassword =   await bcrypt.compare(postData.password, getUser[0].password);
            if(isMatchedPassword){
                //If not completed verification process after register then we will send OTP to verify it
                if(!getUser[0].is_verified){
                    await CommonModel.deleteRecords({whereCon: [{field: "user", value: getUser[0].id}, {field: "otp_type", value: 'register'}], table: 'otp'});
                    var otpNumber = CommonModel.generateNumber(6); //generate 6 digit OTP
                    await CommonModel.insertRecords( {otp: otpNumber, otp_type: 'register', user: getUser[0].id }, 'otp'); //insert OTP details
                    //send OTP on registred mobile number
                    let smsResponse = await CommonModel.sendSMS( { message: `OTP for login on Exammo is ${otpNumber}. This OTP is valid for 10 minutes. Do not share your OTP with anyone.`, contactNumber: '91' + getUser[0].mobile_number} );
                    if(smsResponse){
                        res.status(201).json({
                            "status": "success",
                            "message": "Please verify mobile OTP to complete registration process."
                        });    
                        return
                    }else{
                        res.status(201).json({
                            "status": "error",
                            "message": "There is some problem, please try again later."
                        });
                        return
                    }
                }

                //if blocked user by admin then 
                if(!getUser[0].approved_status){
                    res.status(201).json({
                        "status": "error",
                        "message": "Your account is Inactive. please contact to admin."
                    });
                    return
                }

                const tokenUser = { id: getUser[0].id, username: getUser[0].username, email: getUser[0].email, mobile_number: getUser[0].mobile_number }
                const token = jwt.sign(tokenUser, config.secret, {expiresIn: config.tokenLife})
                var response = {
                    "status": "success",
                    "message": "Login successfully",
                    "user": tokenUser,
                    "token": token, 
                    'otp_status': true
                } 
                res.status(201).json(response); 
            }else{
                var response = {
                    "status": "error",
                    "message": "Please enter correct password"
                }
                res.status(201).json(response); 
            }
        }else{
            res.status(201).json({ "status": "error", "message": "This user is not exist." });
        }
    } catch (error) {
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});

/**
 * Resend Verify OTP for register/forgot password
 */
router.post('/register', async (req, res, next) => {
    try {
        const postData = req.body;
        const addData = {};
        if(!postData.username || postData.username == ""){
            res.status(201).json({
                "status": "error",
                "message": "Username is required."
            });
            return
        }

        if(!postData.email || postData.email == ""){
            res.status(201).json({
                "status": "error",
                "message": "Email address is required."
            });
            return
        }

        if(!postData.mobile_number || postData.mobile_number == ""){
            res.status(201).json({
                "status": "error",
                "message": "Mobile Number is required."
            });
            return
        }

        if(postData.mobile_number.length != 10 ){
            res.status(201).json({
                "status": "error",
                "message": "Mobile Number must be 10 digit."
            });
            return
        }

        if(!postData.password || postData.password == ""){
            res.status(201).json({
                "status": "error",
                "message": "Password is required."
            });
            return
        }

        if(postData.password.length > 30 || postData.password.length < 6){
            res.status(201).json({
                "status": "error",
                "message": "Password length should be between 6 to 30."
            });
            return
        }
        
        if(!postData.password_confirmation || postData.password_confirmation == ""){
            res.status(201).json({
                "status": "error",
                "message": "Confirm Password is required."
            });
            return
        }

        if((postData.password).localeCompare(postData.password_confirmation) != 0){
            res.status(201).json({
                "status": "error",
                "message": "Password and Confirm Password should be same."
            });
            return
        }

        //check duplicate
        let result = await CommonModel.check_duplicate( 'username', postData.username, 'users');
        if(result){
            return res.status(201).json({
                "status": "error",
                "message":"Username is already exists.",
            });
        }

        result = await CommonModel.check_duplicate( 'username', postData.username, 'candidates');
        if(result){
            return res.status(201).json({
                "status": "error",
                "message":"Username is already exists.",
            });
        }

        result = await CommonModel.check_duplicate( 'email', postData.email, 'users');
        if(result){
            return res.status(201).json({
                "status": "error",
                "message": "Email is already exists.",
            });
        }

        result = await CommonModel.check_duplicate( 'email', postData.email, 'candidates');
        if(result){
            return res.status(201).json({
                "status": "error",
                "message": "Email is already exists.",
            });
        }

        result = await CommonModel.check_duplicate( 'mobile_number', postData.mobile_number, 'users');
        if(result){
            return res.status(201).json({
                "status": "error",
                "message": "Mobile Number is already exists.",
            });
        }
        
        result = await CommonModel.check_duplicate( 'mobile_number', postData.mobile_number, 'candidates');
        if(result){
            return res.status(201).json({
                "status": "error",
                "message": "Mobile Number is already exists.",
            });
        }

        result = await CommonModel.check_duplicate( 'referral_code', postData, 'field_executive_master', 'referral_code');
        if(result != 'key_not_exist'){
            if(result == 0){
                return res.status(201).json({
                    "status": "error",
                    "message": "Referral code is invalid.",
                });
            }else{
                addData.referral_code = postData.referral_code
            }
        }
        addData.username = postData.username
        addData.name = postData.username
        addData.email = postData.email
        addData.mobile_number = postData.mobile_number
        addData.password = postData.password
        //Hash password
        salt = await bcrypt.genSalt(10);
        addData.password =   await bcrypt.hash(postData.password, salt);

        let candidateInsert = await CommonModel.insertRecords( { username: postData.username, email: postData.email, mobile_number: postData.mobile_number, status: 1}, 'candidates');

        if(candidateInsert){
            addData.userDetailsId = candidateInsert;
            addData.role_id = 6;
            addData.user_type = 6;
            addData.approved_status = 1;
            addData.is_verified = 0;
            let insertUser = await CommonModel.insertRecords( addData, 'users');
            //if user inserted successfully
            if(insertUser){
                /* let deleteCandidate = await CommonModel.deleteRecords({whereCon: [{field: "user", value: insertUser}, {field: "otp_type", value: 'register'}], table: 'otp'}); */
                var otpNumber = CommonModel.generateNumber(6); //generate 6 digit OTP
                await CommonModel.insertRecords( {otp: otpNumber, otp_type: 'register', user: insertUser }, 'otp'); //insert OTP details
                //send OTP on registred mobile number
                let smsResponse = await CommonModel.sendSMS( { message: `OTP for login on Exammo is ${otpNumber}. This OTP is valid for 10 minutes. Do not share your OTP with anyone.`, contactNumber: '91' + postData.mobile_number} );
                if(smsResponse){
                    res.status(201).json({
                        "status": "success",
                        "message": "Please verify mobile OTP to complete registration process."
                    });    
                }else{
                    res.status(201).json({
                        "status": "success",
                        "message": "Please login and verify OTP to complete one time verification process."
                    });
                }
            }else{
                let deleteCandidate = await CommonModel.deleteRecords({whereCon: [{field: "id", value: candidateInsert}], table: 'candidates'});
                res.status(201).json({
                    "status": "error",
                    "message": "There is some problem, please try again later."
                });
            }
        }else{
            res.status(201).json({
                "status": "error",
                "message": "There is some problem, please try again later."
            });
        }
    } catch (error) {
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});

/**
 * Resend Verify OTP for register/forgot password
 */
router.post('/resendOtp', async (req, res, next) => {
    try {
        const postData = req.body;
        if(!postData.username){ res.status(201).json({ "status": "error", "message": "Username is required." }); return }
        if(!postData.type){ res.status(201).json({ "status": "error", "message": "Type is required." }); return }
        
        let getUser = await CommonModel.getRecords({whereCon: [{field: "username", value: postData.username}], table: 'users', select: 'id, mobile_number, is_verified, forgot_password_request'});

        if(getUser.length){
            if(postData.type == 'register'){
                if(getUser[0].is_verified){
                    res.status(201).json({
                        "status": "error",
                        "message": "User already verified"
                    });
                    return;
                }
            }else if(postData.type == 'forgot_password'){
                if(!getUser[0].forgot_password_request){
                    res.status(201).json({
                        "status": "error",
                        "message": "Sorry, we have not found any forgot password request."
                    });
                    return;
                }
            }else{
                res.status(201).json({
                    "status": "error",
                    "message": "This user is not exist."
                });
                return;
            }

            //delete old OTP
            await CommonModel.deleteRecords({whereCon: [{field: "user", value: getUser[0].id}, {field: "otp_type", value: postData.type}], table: 'otp'});
        
            //Generate OTP and insert in OTP table
            var otpNumber = CommonModel.generateNumber(6); //generate 6 digit OTP
            await CommonModel.insertRecords( {otp: otpNumber, otp_type: postData.type, user: getUser[0].id }, 'otp'); //insert OTP details
        
            //send OTP on registred mobile number
            let smsResponse = await CommonModel.sendSMS( { message: `OTP for login on Exammo is ${otpNumber}. This OTP is valid for 10 minutes. Do not share your OTP with anyone.`, contactNumber: '91' + getUser[0].mobile_number} );

            if(smsResponse){
                res.status(201).json({
                    "status": "success",
                    "message": "Please verify mobile OTP"
                });    
            }else{
                res.status(201).json({
                    "status": "error",
                    "message": "There is some problem to send OTP, please try again later."
                });
            }
        }else{
            res.status(201).json({
                "status": "error",
                "message": "This user is not exist."
            });
        }
    } catch (error) {
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});

/**
 * Verify OTP for register/forgot password
 */
router.post('/verifyOtp', async (req, res, next) => {
    try {
        const postData = req.body;
        if(!postData.username){ res.status(201).json({ "status": "error", "message": "Username is required." }); return }
        if(!postData.otp){ res.status(201).json({ "status": "error", "message": "OTP is required." }); return }
        if(!postData.type){ res.status(201).json({ "status": "error", "message": "Type is required." }); return }
        
        let getUser = await CommonModel.getRecords({whereCon: [{field: "username", value: postData.username}], table: 'users', select: 'id, mobile_number, is_verified, forgot_password_request'});

        if(getUser.length){
            let getOtp = await CommonModel.getRecords({whereCon: [{field: "user", value: getUser[0].id}, {field: "otp_type", value: postData.type},  {field: "otp", value: postData.otp}], table: 'otp', select: 'created_at'});
            
            if(getOtp.length){
                var timestamp = new Date();
                var current_time = moment(timestamp);
                var otpDate = moment(getOtp[0].created_at).format(),
                otpDate = moment(otpDate);
                if(current_time.diff(otpDate, 'minutes') > 10){
                    res.status(201).json({ "status": "error", "message": "OTP has been expired, please resend OTP." }); return;
                }
                
                if(postData.type == 'register'){
                    if(getUser[0].is_verified){ 
                        res.status(201).json({ "status": "error", "message": "User already verified" }); return; 
                    }else{
                        await CommonModel.updateRecords({ table: 'users', whereCon: [{field: "username", value: postData.username}] }, { is_verified: 1 });
                        await CommonModel.deleteRecords({table: 'otp', whereCon: [{field: "user", value: getUser[0].id}, {field: "otp_type", value: postData.type}]});
                    }
                }else if(postData.type == 'forgot_password'){
                    if(!getUser[0].forgot_password_request){ res.status(201).json({ "status": "error", "message": "Sorry, we have not found any forgot password request." }); return; }
                }else{
                    res.status(201).json({ "status": "error", "message": "This user is not exist." }); return;
                }
                res.status(201).json({ "status": "success", "message": "OTP verified successfully." });
            }else{
                res.status(201).json({ "status": "error", "message": "Please enter correct OTP to verify details." });
            }
        }else{
            res.status(201).json({ "status": "error", "message": "This user is not exist." });
        }    
    } catch (error) {
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});

/**
 * Forgot password
 */
router.post('/forgotPassword', async (req, res, next) => {
    try {
        const postData = req.body;
        if(!postData.mobile_number){ res.status(201).json({ "status": "error", "message": "Mobile Number is required." }); return }
        
        let getUser = await CommonModel.getRecords({whereCon: [{field: "mobile_number", value: postData.mobile_number}], table: 'users', select: 'id,username'});

        if(getUser.length){
            //delete old OTP
            await CommonModel.deleteRecords({whereCon: [{field: "user", value: getUser[0].id}, {field: "otp_type", value: 'forgot_password'}], table: 'otp'});
        
            var otpNumber = CommonModel.generateNumber(6); //generate 6 digit OTP
            await CommonModel.insertRecords( {otp: otpNumber, otp_type: 'forgot_password', user: getUser[0].id }, 'otp'); //insert OTP details
           
            //send OTP on registred mobile number
            let smsResponse = await CommonModel.sendSMS( { message: `OTP for login on Exammo is ${otpNumber}. This OTP is valid for 10 minutes. Do not share your OTP with anyone.`, contactNumber: '91' + postData.mobile_number} );
            if(smsResponse){
                await CommonModel.updateRecords({ table: 'users', whereCon: [{field: "username", value: getUser[0].username}] }, { forgot_password_request: 1 });
                res.status(201).json({
                    "status": "success",
                    "message": "Please verify mobile OTP for reset password."
                });    
            }else{
                res.status(201).json({
                    "status": "error",
                    "message": "There is some problem, please try again later."
                });
            }
        }else{
            res.status(201).json({ "status": "error", "message": "This user is not exist." });
        }    
    } catch (error) {
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});

/**
 * Reset Password
 */
 router.post('/resetPassword', async (req, res, next) => {
    try {
        const postData = req.body;
        if(!postData.username){ res.status(201).json({ "status": "error", "message": "Username is required." }); return }
        if(!postData.password){ res.status(201).json({ "status": "error", "message": "Password is required." }); return }
        if(!postData.password_confirmation){ res.status(201).json({ "status": "error", "message": "Confirm Password is required." }); return }
        if(postData.password != postData.password_confirmation){ res.status(201).json({ "status": "error", "message": "Password and Confirm Password must be same" }); return }

        let getUser = await CommonModel.getRecords({whereCon: [{field: "username", value: postData.username}], table: 'users', select: 'id, username, forgot_password_request'});
        
        if(getUser.length){
            if(getUser[0].forgot_password_request){
                salt = await bcrypt.genSalt(10);
                let newPassword =   await bcrypt.hash(postData.password, salt);
                await CommonModel.updateRecords({ table: 'users', whereCon: [{field: "username", value: getUser[0].username}] }, { forgot_password_request: 0, password: newPassword });
                await CommonModel.deleteRecords({table: 'otp', whereCon: [{field: "user", value: getUser[0].id}, {field: "otp_type", value: 'forgot_password'}]});
                res.status(201).json({ "status": "success", "message": "Password updated successfully." });
            }else{
                res.status(201).json({ "status": "error", "message": "Sorry, we can't update this password, password already updated." });
            }
        }else{
            res.status(201).json({ "status": "error", "message": "This user is not exist." });
        } 
    } catch (error) {
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
    
});
/**END - Exammo APIs*/

router.post("/*", authUtil.ensureAuthenticated, function (req, res, next) {
    res
        .status(403)
        .json({message: "forbidden"});
});

module.exports = router;