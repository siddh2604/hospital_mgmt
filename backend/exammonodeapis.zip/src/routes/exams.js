var express = require('express');
var router = express.Router();
var CommonModel = require('../models/common');
const config = require('./../config');
const authUtil = require('./authUtil.js');
var timestamp = new Date();
timestamp = timestamp.getTime() + timestamp.getTimezoneOffset() * 60000; //to UTC timestamp
var moment = require('moment');
const AWS = require('aws-sdk');
const S3 = new AWS.S3({region: config.AWS_DEFAULT_REGION});

/**
 * Get exam categories
 */
router.get('/getCategories', async (req, res, next) => {
    try {
        let categoriesList = await CommonModel.getRecords({whereCon: [{field: "status", value: 1}], table: 'category_masters', select: 'id, name, image'}); //color, description
        //[{},{},{}] | []
        if(categoriesList.length){
            //get public image path from AWS S3 bucket
            categoriesList.forEach((val, key) => {
                let publicImage = S3.getSignedUrl('getObject', {
                    Bucket: config.AWS_BUCKET,
                    Key: val.image,
                    Expires: config.signedUrlExpireSeconds
                });
                categoriesList[key].image = publicImage
            });
        }
        res.status(201).json({ "status": "success", "items": categoriesList });

    } catch (error) {
        console.log(error)
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});

/**
 * Get exam State
 */
router.get('/examStates', async (req, res, next) => {
    try {
        let result = await CommonModel.getRecords({whereCon: [{field: "country_id", value: 101}], table: 'states', select: 'id, name'});
        res.status(201).json({ "status": "success", "items": result });   
    } catch (error) {
        console.log(error)
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});

/**
 * Get exam Qualifications
 */
router.get('/examQualifications', async (req, res, next) => {
    try {
        let result = await CommonModel.getRecords({whereCon: [{field: "status", value: 1}], table: 'qualification_master', select: 'id, name'});
        res.status(201).json({ "status": "success", "items": result });   
    } catch (error) {
        console.log(error)
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});

/** 
 * Get exam list with pagination for latest/upcoming
 */
router.get('/examList', async (req, res, next) => {
    try {
        const getParams = req.query;
        const currentDate = moment(new Date()).format("YYYY-MM-DD");
        const pagination = {page: 1, pageSize: 10}
       
        if(!getParams.exam_type){ res.status(201).json({ "status": "error", "message": "Exam Type is required." }); return }
        
        if(!['latest','upcoming'].includes(getParams.exam_type)){ res.status(201).json({ "status": "error", "message": "Exam Type is invalid" }); return }
       
        if(getParams.page){  pagination.page = getParams.page }
        
        if(getParams.pageSize){  pagination.pageSize = getParams.pageSize }

        const whenCondtion = []
            whenCondtion.push({field: "exam_type", value: getParams.exam_type});// added type condition
            whenCondtion.push({field: "status", value: 1});// added status condition

        if(getParams.category) { whenCondtion.push({field: "category", value: getParams.category}); }// added category condition

        if(getParams.exam_type == 'latest'){
            whenCondtion.push({field: "application_start_date", value: currentDate, extraCondition: "<="});// added application_start_date condition
            whenCondtion.push({field: "application_end_date", value: currentDate, extraCondition: ">="});// added application_end_date condition
        }
       
        let result = await CommonModel.getRecords({whereCon: whenCondtion, table: 'exams', select: '*', pagination: pagination});
        let resultCount = await CommonModel.getRecords({whereCon: whenCondtion, table: 'exams', select: 'count(*) as count'});
        resultCount = resultCount[0].count;
        const totalPages = resultCount / getParams.pageSize;
        if(result.length){
            //get public image path from AWS S3 bucket
            result.forEach((val, key) => {
                //get exam logo public path from aws S3
                if(val.exam_logo){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.exam_logo,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].exam_logo = publicImage
                } 

                //get exam_notification public path from aws S3
                if(val.exam_notification){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.exam_notification,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].exam_notification = publicImage
                }

                //get previous_year_paper public path from aws S3
                if(val.previous_year_paper){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.previous_year_paper,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].previous_year_paper = publicImage
                }

                //get previous_cut_off_mark public path from aws S3
                if(val.previous_cut_off_mark){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.previous_cut_off_mark,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].previous_cut_off_mark = publicImage
                }                 
            });
        }
        res.status(201).json({ "status": "success", "items": result, totalRecords: resultCount, page: getParams.page, pageSize: getParams.pageSize, totalPages: Math.ceil(totalPages)});   
    } catch (error) {
        console.log(error)
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});

/** 
 * View exam details apis
 */
router.get('/examDetails', async (req, res, next) => {
    try {
        const getParams = req.query;

        if(!getParams.id){ res.status(201).json({ "status": "error", "message": "Exam id is required." }); return }
        
        let result = await CommonModel.getRecords({whereCon: [{field: "id", value: getParams.id }], table: 'exams', select: '*'});
        if(result.length){
            //get public image path from AWS S3 bucket
            result.forEach((val, key) => {
                //get exam logo public path from aws S3
                if(val.exam_logo){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.exam_logo,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].exam_logo = publicImage
                } 

                //get exam_notification public path from aws S3
                if(val.exam_notification){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.exam_notification,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].exam_notification = publicImage
                }

                //get previous_year_paper public path from aws S3
                if(val.previous_year_paper){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.previous_year_paper,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].previous_year_paper = publicImage
                }

                //get previous_cut_off_mark public path from aws S3
                if(val.previous_cut_off_mark){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.previous_cut_off_mark,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].previous_cut_off_mark = publicImage
                }                 
            });
        }
        const items = (result.length > 0)? result[0] : {};
        res.status(201).json({ "status": "success", "items": items});   
    } catch (error) {
        console.log(error)
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});

/** 
 * View exam populer apis
 */
router.get('/examPopuler', async (req, res, next) => {
    try {
        
        let result = await CommonModel.getRecords({whereCon: [{field: "is_popular", value: 1},{field: "exam_type", value: "latest"}], table: 'exams', select: '*'});

        if(result.length){
            //get public image path from AWS S3 bucket
            result.forEach((val, key) => {
                //get exam logo public path from aws S3
                if(val.exam_logo){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.exam_logo,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].exam_logo = publicImage
                } 

                //get exam_notification public path from aws S3
                if(val.exam_notification){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.exam_notification,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].exam_notification = publicImage
                }

                //get previous_year_paper public path from aws S3
                if(val.previous_year_paper){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.previous_year_paper,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].previous_year_paper = publicImage
                }

                //get previous_cut_off_mark public path from aws S3
                if(val.previous_cut_off_mark){
                    let publicImage = S3.getSignedUrl('getObject', {
                        Bucket: config.AWS_BUCKET,
                        Key: val.previous_cut_off_mark,
                        Expires: config.signedUrlExpireSeconds
                    });
                    result[key].previous_cut_off_mark = publicImage
                }                 
            });
        }
        res.status(201).json({ "status": "success", "items": result});   
    } catch (error) {
        console.log(error)
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});

/** 
 * View exam submitChoice apis
 */
router.post('/submitChoice', authUtil.ensureAuthenticated, async (req, res, next) => {
    try {
        var userId = req.user.id

        const postData = req.body;
        if(!postData.age){ res.status(201).json({ "status": "error", "message": "Age is required." }); return }
        if(!postData.qualification_id){ res.status(201).json({ "status": "error", "message": "Qualification is required." }); return }
        if(!postData.state_id){ res.status(201).json({ "status": "error", "message": "State is required." }); return }
        
        let candidateInsert = await CommonModel.insertRecords( { user_id: userId, age: postData.age, qualification_id: postData.qualification_id, state_id: postData.state_id}, 'candidate_choice');

         if(candidateInsert){
                    res.status(201).json({
                        "status": "success",
                        "message": "Add candidate choice data."
                    });
        await CommonModel.updateRecords({ table: 'users', whereCon: [{field: "id", value: userId}] }, { is_popup: 1 });
                }

    } catch (error) {
        res.status(201).json({ "status": "error", "message": "There is some problem, please try again later." })
    }
});


router.post("/*", authUtil.ensureAuthenticated, function (req, res, next) {
    res
        .status(403)
        .json({message: "forbidden"});
});

module.exports = router;