var express = require('express');
var router = express.Router();
var MessageModel = require('../models/message');
const authUtil = require('./authUtil.js');
var CommonModel = require('../models/common');
var UserModel = require('../models/user');
const config = require('./../config');

var timestamp = new Date();

timestamp = timestamp.getTime() + timestamp.getTimezoneOffset() * 60000; //to UTC timestamp


router.post('/sendMessage', authUtil.ensureAuthenticated, async(req, res, next) => {
    const postData = req.body;
    
    if(postData.receiver_id == undefined || postData.receiver_id == ""){
        res.status(200).json({
            "status": "error",
            "message": "Receiver ID is required."
        });
    }

    if(postData.message == undefined || postData.message == ""){
        res.status(200).json({
            "status": "error",
            "message": "Message is required."
        });
    }
    postData.sender_id = req.user.id;
    MessageModel.sendMessage(postData, function(err, result){
        if(err){
            res.status(200).json({status: "error", message: "There is some problem, please try again later."});
        } else {
            var params = {id: req.user.id, senderName: req.user.first_name +" "+ req.user.middle_name + " " + req.user.last_name, senderProfileImage: req.user.profile_image, receiver_id: req.body.receiver_id }
            MessageModel.loadUserMessages(params,function(err, result){
                if(err){
                    res.status(200).json({
                        "status": "error",
                        "message": "There is some problem, please try again later"
                    });
                    return
                }else{
                    var chatRoom = [];
                    if(result.length > 0){
                        result.forEach(element => {
                            if(req.user.id != element.sender_id){
                                element.endUserId = element.sender_id
                                element.endUserName = element.senderName
                                element.endUserImage = element.senderProfileImage
                            }else if(req.user.id != element.receiver_id){
                                element.endUserId = element.receiver_id
                                element.endUserName = element.receiverName
                                element.endUserImage = element.receiverProfileImage
                            }
                            chatRoom.push(element);
                        });
                    }
                    var response = {
                        "status": "success",
                        "message": "Message Sent Successfully",
                        "items": chatRoom
                    }
                    res.status(200).json(response);    
                }
            })
        }
    })
});

router.get('/messageRoom', authUtil.ensureAuthenticated, async (req, res, next) => {
    var params = {id: req.user.id, senderName: req.user.first_name +" "+ req.user.middle_name + " " + req.user.last_name, senderProfileImage: req.user.profile_image }

    MessageModel.messageRoom(params,function(err, result){
        if(err){
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var chatRoom = [];
            var userIds = [];
            if(result.length > 0){
                result.forEach(element => {
                    var key1 = element.sender_id + "_" + element.receiver_id
                    var key2 = element.receiver_id + "_" + element.sender_id
                    if(!userIds.includes(key1) && !userIds.includes(key2)){
                        userIds.push(key1);
                        userIds.push(key2);
                        if(req.user.id != element.sender_id){
                            element.endUserId = element.sender_id
                            element.endUserName = element.senderName
                            element.endUserImage = element.senderProfileImage
                        }else if(req.user.id != element.receiver_id){
                            element.endUserId = element.receiver_id
                            element.endUserName = element.receiverName
                            element.endUserImage = element.receiverProfileImage
                        }
                        chatRoom.push(element);
                    }
                });
            }
            if(req.query.receiver_id != undefined && req.query.receiver_id != ""){
                var key11 = req.query.receiver_id + "_" + req.user.id
                var key12 = req.user.id + "_" + req.query.receiver_id
                if(!userIds.includes(key11) && !userIds.includes(key12)){
                    params.receiver_id = req.query.receiver_id;
                    console.log("Create default channel")
                    UserModel.getUserById({id: req.query.receiver_id}, function(err, userObj){
                        if(err){
                            res.status(200).json({
                                "status": "error",
                                "message": "There is some problem, please try again later"
                            });
                        }else{
                            if(userObj.length > 0 ){
                                const newChat =  {
                                    "id": Math.floor(100000 + Math.random() * 900000),
                                    "sender_id": req.user.id,
                                    "receiver_id": req.query.receiver_id,
                                    "message": "",
                                    "maxDate": new Date(),
                                    "senderName": req.user.first_name +" "+ req.user.middle_name + " " + req.user.last_name, 
                                    "senderProfileImage": config.base_url + "public/images/users/profiles/" + req.user.profile_image,
                                    "receiverName": userObj[0].first_name + " " + userObj[0].middle_name + " " + userObj[0].last_name,
                                    "receiverProfileImage": config.base_url + "public/images/users/profiles/" + userObj[0].profile_image,
                                    "unreadCount": 0,
                                    "endUserId": req.query.receiver_id,
                                    "endUserName":  userObj[0].first_name + " " + userObj[0].middle_name + " " + userObj[0].last_name,
                                    "endUserImage": config.base_url + "public/images/users/profiles/" + userObj[0].profile_image
                                };
                                chatRoom.unshift(newChat);

                                //chatRoom.push(newChat)
                                var response = {
                                    "status": "success",
                                    "items": chatRoom
                                }
                                res.status(200).json(response); 
                            }else{
                                var response = {
                                    "status": "error",
                                    "message": "This user is not exist"
                                }
                                res.status(200).json(response); 
                            }
                        }
                    });
                }else{
                    var response = {
                        "status": "success",
                        "items": chatRoom
                    }
                    res.status(200).json(response); 
                }
            }else{
                var response = {
                    "status": "success",
                    "items": chatRoom
                }
                res.status(200).json(response); 
            }
            /* }else{
                var response = {
                    "status": "success",
                    "items": chatRoom
                }
                res.status(200).json(response); 
            } */
              
        }
    })
});

router.get('/loadUserMessages', authUtil.ensureAuthenticated, async (req, res, next) => {
    var params = {id: req.user.id, senderName: req.user.first_name +" "+ req.user.middle_name + " " + req.user.last_name, senderProfileImage: req.user.profile_image, receiver_id: req.query.receiver_id }
    MessageModel.loadUserMessages(params,function(err, result){
        if(err){
            res.status(200).json({
                "status": "error",
                "message": "There is some problem, please try again later"
            });
            return
        }else{
            var chatRoom = [];
            if(result.length > 0){
                result.forEach(element => {
                    if(req.user.id != element.sender_id){
                        element.endUserId = element.sender_id
                        element.endUserName = element.senderName
                        element.endUserImage = element.senderProfileImage
                    }else if(req.user.id != element.receiver_id){
                        element.endUserId = element.receiver_id
                        element.endUserName = element.receiverName
                        element.endUserImage = element.receiverProfileImage
                    }
                    chatRoom.push(element);
                });
            }
            var response = {
                "status": "success",
                "items": chatRoom
            }
            res.status(200).json(response);    
        }
    })
});

router.get('/readMessage', authUtil.ensureAuthenticated, async (req, res, next) => {
    var params = {id: req.user.id, senderName: req.user.first_name +" "+ req.user.middle_name + " " + req.user.last_name, senderProfileImage: req.user.profile_image, receiver_id: req.query.receiver_id }

    CommonModel.customUpdate({ table: 'messages', whereCon: [{field: "sender_id", value: req.user.id}, {field: "receiver_id", value: req.query.receiver_id}] }, { read_status: 1 }, function(err, responseCount){
        if(err){
            res.status(200).json({status: "error", message: err});
        } else {
            var response = {
                "status": "success",
                "message": "Messages status updated"
            }
            res.status(200).json(response);  
        }
    })
});

module.exports = router;