module.exports = {
   "mysql": {
      host: "localhost",
      user: "root",
      password: "",
      database: "exammo",
      port:3306
   },
   "SMS_URL": "https://api.text-world.com/api/v2/SendSMS",
   "SMS_API_KEY": "bKkfETGa4KvkpHl41VTPmdoTQoxxLAWivp4MqoDTt+M=",
   "SMS_CLIENT_ID": "3b96f158-e46e-431c-b8d9-6a8be8a50299",
   "SMS_SENDER_ID": "EXAMMO",
   "S3Bucket": process.env.S3Bucket || "exammo-dev",
   "region": process.env.region || "ap-south-1",

   "AWS_ACCESS_KEY_ID": "AKIAQRVQBK3IHI2BQKGG",
   "AWS_SECRET_ACCESS_KEY": "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",
   "AWS_DEFAULT_REGION": "ap-south-1",
   "AWS_BUCKET":"exammo-dev",
   "AWS_S3_URL": "https://exammo-dev.s3.ap-south-1.amazonaws.com/",
   "AWS_S3_FILE_EXPIRY":"+5 minutes",
   "signedUrlExpireSeconds": 60 * 5,
   "ADMIN_EMAIL" : "dinesh.jobsquare@gmail.com",



   "secret": process.env.secret || "exyAU0cwm2weEqyG3Y3C",
   "refreshTokenSecret": process.env.refreshTokenSecret || "LdlyhvYRVNkD1wlpIfks",
   "port": 3000,
   "tokenLife": parseInt(process.env.tokenLife) || 90*86400,
   "refreshTokenLife": parseInt(process.env.refreshTokenLife) || 91*86400,
   
   "endpoint": process.env.endpoint || "http://localhost:8000",
   "stage": process.env.stage || "dev",
   "S3EmailFolder": process.env.S3EmailFolder || "email_supermatch/",
   "CloudFront": "https://dev-assets.jobsquare.com/",
   "sqsResource": process.env.sqsResource || "https://sqs.ap-south-1.amazonaws.com/923642526244/dev-jobsquare",
   "sqsResourcePriority": process.env.sqsResource || "https://sqs.ap-south-1.amazonaws.com/923642526244/jobsquarepriority",
   "replyEmailAddress": process.env.replyEmailAddress || "social@jobsquare.com",
   "sourceEmailAddress": process.env.sourceEmailAddress || "social@jobsquare.com",
   "rootPath": process.env.rootPath || "https://v3.jobsquare.com",
   "FCMKEY": process.env.FCMKEY || "AAAA2qmb8Hw:APA91bGZhVtYKm7mZ2eMRCA69mBQo3A-hlXFEQTnLaADNWs8d5XnDwcoQNcVhkTeUD1eJ84YKeCSD24X2HXRoSBDcNqw-iLXqKx7IrK_T1y3tUmenvPd3LoHh5y5Eg4Ms6VmF4w5M99Z",
   "apiEndpoint":process.env.apiEndpoint || "http://localhost:3000/",
   "officialCompanyname": "JobSquare Network Private Limited",
   "razorpayAccountId": process.env.razorpayAccountId || "DlefeKxISZz0dq",
   "razorpayKeyId": process.env.razorpayKeyId || "rzp_test_8ZkTDwRj8Te4eD",  //rzp_live_wxgp3NWAUY7u10
   "razorpayKeySecret": process.env.razorpayKeySecret || "hNZM8xRn4f9X56DomJRBfOWW", //YJZWrXsZOu3iQAUjUhAJnwjx
   "razorpayCurrency": process.env.razorpayCurrency || "INR",
   "razorpayWebhookSecret": process.env.razorpayWebhookSecret || "QWr6K@zew7gF@Kq",
   "defaultTimezoneOffSet": -330,
   "awsFileUploadLimit": process.env.awsFileUploadLimit || 11, //size in MB like: 10 MB
   "downloadAndroidApp": process.env.downloadAndroidApp || "https://play.google.com/store/apps/details?id=com.jobsquare.mobile&referrer=SYSTEM_GENERATED_MAIL",
   "downloadIOSApp": process.env.downloadIOSApp || "https://play.google.com/store/apps/details?id=com.jobsquare.mobile&referrer=SYSTEM_GENERATED_MAIL",
   "encryptSecretKey": process.env.encryptSecretKey || "z6kZgb2meaIi9FZDpj9GVMlJYgi2FL2O",
   "adminContactNumber": process.env.adminContactNumber || 8690415675, 
   "androidAppUrl": "https://code.jobsquare.com/static/install-apps?referrer=SYSTEM_GENERATED_EMAIL&utm_medium=email",
   "iosAppUrl": "https://code.jobsquare.com/static/install-apps?referrer=SYSTEM_GENERATED_EMAIL&utm_medium=email"
}